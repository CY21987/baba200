Live for Speed S3 0.6R DCON MultiMod
==================================================
Draggo   ---   http://podfolio.eu
==================================================

Changelog:
- No "Cars don't match host cars" - 40% of work by MeepMeep (turbofan)
- Set server to public with /modified=yes - by MeepMeep (turbofan)
- No synchronisation

Instruction on how to rerun modified public server:
Start the server with password set //pass=password and without /modified=yes in setup.cfg
Then, in the server window type /modified=yes


Thanks to:
MeepMeep (turbofan) - for idea and big help
Eastbam - testing
Xspeed - testing

==================================================
MultiMod <- this word is invented by 42DxWeed :)
==================================================
